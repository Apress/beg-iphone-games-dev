//
//  BBArrowButton.h
//  SpaceRocks
//
//  Created by ben smith on 7/07/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBButton.h"

@interface BBArrowButton : BBButton {

}

@end
