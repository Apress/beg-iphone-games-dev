//
//  BBUFOMissile.h
//  SpaceRocks3D
//
//  Created by ben smith on 28/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BBMissile.h"

@interface BBUFOMissile : BBMissile {

}

@end
