//
//  AsteroidsView.m
//  Asteroids
//
//  Created by Scott Penberthy on 3/13/10.
//  Copyright 2010 Acme Games. All rights reserved.
//

#import "AsteroidsView.h"
#import "VectorSprite.h"
#import "AtlasSprite.h"
#import "TextSprite.h"
#import "Defs.h"

@implementation AsteroidsView

#if (CODE_VERSION < 6)
- (id)initWithCoder: (NSCoder *) coder {
    if (self = [super initWithCoder: coder]) {
        // Initialization code
		test = [[Sprite alloc] init];
		test.x = 50;
		test.y = 100;
		test.width = 100;
		test.height = 200;
		test.r = 0.0;
		test.g = 1.0;
		test.b = 0.0;
    }
    return self;
}
#endif

#if (CODE_VERSION == 6)

#define kVectorArtCount 4
#define kVectorScale 1.0
static CGFloat kVectorArt[] = {
	-50,100,  50,100,  50,-100,  -50,-100,
};
- (id) initWithCoder: (NSCoder *) coder {
	if (self = [super initWithCoder: coder]) {
		test = [VectorSprite withPoints: kVectorArt count: kVectorArtCount];
		test.scale = 1.0;
		test.x = 50;
		test.y = 100;
		test.r = 0.0;
		test.g = 1.0;
		test.b = 0.0;
		test.alpha = 1.0;
	}
	return self;
}

#endif

#if (CODE_VERSION == 7)
#define kVectorArtCount 12
static CGFloat kVectorArt[] = {
	-7,12, 1,9, 8,12, 15,5, 8,3, 15,-4, 8,-12,
	-3,-10, -6,-12, -14,-7, -10,0, -14,5
};
- (id) initWithCoder: (NSCoder *) coder {
	if (self = [super initWithCoder: coder]) {
		test = [VectorSprite withPoints: kVectorArt count: kVectorArtCount];
		test.scale = 1.0;
		test.x = 50;
		test.y = 100;
		test.r = 0.0;
		test.g = 1.0;
		test.b = 0.0;
		test.alpha = 1.0;
	}
	return self;
}
#endif


/**

- (id) initWithCoder: (NSCoder *) coder {
	if (self = [super initWithCoder: coder]) {
		test = [TextSprite withString: @"Hello World!"];
		test.r = 0;
		test.g = 1.0;
		test.b = 1.0;
		test.x = -85;
		test.y = -30;
		test.rotation = 20;
		[(TextSprite *) test setFontSize: 36];
	}
	return self;
}
 **/



#if (CODE_VERSION == 8)
 
#define RANDOM_SEED() srandom(time(NULL))
#define RANDOM_INT(__MIN__, __MAX__) ((__MIN__) + random() % ((__MAX__+1) - (__MIN__)))
#define kSteps 8
#define kSpeed 200
#define kFPS 20.0
#define kBounce 30
#define kDirForward 0
#define kDirBackward 1
#define kDirUp 2
#define kDirDown 3
static int kForward[] =  {0,1,2,3,4,5,6,7};
static int kUpward[] =   {8,9,10,11,12,13,14,15};
static int kDownward[] = {16,17,18,19,20,21,22,23};
static int kBackward[] = {24,24,25,26,27,28,29,30};

/** for mario.png
 #define kSteps 6
static int kForward[] = {10,11,11,10,9,9};
static int kBackward[] = {22,23,23,22,21,21};
static int kUpward[] = {4,5,5,4,3,3};
static int kDownward[] = {16,17,17,16,15,15};
 **/

- (id) initWithCoder: (NSCoder *) coder {
	if (self = [super initWithCoder: coder]) {
		test = [AtlasSprite fromFile: @"walk.png" withRows: 4 withColumns: 8];
		test.angle = 0;
		test.speed = kSpeed;
		direction = kDirForward;
		timer = [NSTimer scheduledTimerWithTimeInterval: 1.0/kFPS
												 target:self 
											   selector:@selector(gameLoop) 
											   userInfo:nil 
												repeats:YES];
		self.backgroundColor = [UIColor whiteColor];
	}
	return self;
}

- (void) gameLoop
{
	frame = (frame+1)%kSteps;
	[test tic: 1.0/kFPS];
	if (test.offScreen) {
		RANDOM_SEED();
		int toCenter = round(atan2(-test.y,-test.x)*180.0/3.141592);
		if (toCenter < 0) toCenter += 360;
		int bounce = (toCenter+RANDOM_INT(-kBounce,kBounce))%360;
		if (bounce <= 60 || bounce >= 300) direction = kDirForward;
		else if (bounce > 60 && bounce < 120) direction = kDirUp;
		else if (bounce >= 120 && bounce <= 240) direction = kDirBackward;
		else direction = kDirDown;
		test.angle = bounce;
		test.scale = 0.4+1.6*RANDOM_INT(0,10)/10.0;
		while (test.offScreen) [test tic: 1.0/kFPS];
	}
	switch (direction) {
		case kDirForward:		test.frame = kForward[frame]; break;
		case kDirBackward:		test.frame = kBackward[frame]; break;
		case kDirUp:			test.frame = kUpward[frame]; break;
		case kDirDown:			test.frame = kDownward[frame]; break;
	}
	[self setNeedsDisplay];
}

#endif

#if (CODE_VERSION > 8)
- (id) initWithCoder: (NSCoder *) coder {
	if (self = [super initWithCoder: coder]) {
		test = [TextSprite withString: @"Hello World!"];
		test.r = 0;
		test.g = 1.0;
		test.b = 1.0;
		test.x = -85;
		test.y = -30;
		test.rotation = 20;
		[(TextSprite *) test setFontSize: 36];
	}
	return self;
}
#endif
	
#if (CODE_VERSION == 0)

- (void)drawRect:(CGRect)rect {	
	// Get a graphics context, saving its state
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGContextSaveGState(context);
	
	// Reset the transformation
	CGAffineTransform t0 = CGContextGetCTM(context);
	t0 = CGAffineTransformInvert(t0);
	CGContextConcatCTM(context,t0);
	
	// Draw a green rectangle
	CGContextBeginPath(context);
	CGContextSetRGBFillColor(context, 0,1,0,1);
	CGContextAddRect(context, CGRectMake(0,0,100,200));
	CGContextClosePath(context);
	CGContextDrawPath(context,kCGPathFill);
	
	CGContextRestoreGState(context);
}

#endif

#if  (CODE_VERSION == 1)
- (void)drawRect:(CGRect)rect {	
	// Get a graphics context, saving its state
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGContextSaveGState(context);
	
	// Reset the transformation
	CGAffineTransform t0 = CGContextGetCTM(context);
	t0 = CGAffineTransformInvert(t0);
	CGContextConcatCTM(context,t0);
	
	// Draw a green rectangle
	[test updateBox];
	[test draw: context];
	
	CGContextRestoreGState(context);
}
#endif

#if (CODE_VERSION >= 2) && (CODE_VERSION <= 7)
- (void)drawRect:(CGRect)rect {	
	// Get a graphics context, saving its state
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGContextSaveGState(context);
	
	// Reset the transformation
	CGAffineTransform t0 = CGContextGetCTM(context);
	t0 = CGAffineTransformInvert(t0);
	CGContextConcatCTM(context,t0);
	
	// Draw a green rectangle
	[test updateBox];
	[test draw: context];
	
	// Draw it again, in purple, rotated
	test.x = 75;
	test.y = 100;
	test.r = 1.0;
	test.g = 0.0;
	test.b = 1.0;
	test.alpha = 0.25;
	test.scale = 0.5;
	test.rotation = 90;
	[test updateBox];
	[test draw: context];
	
	CGContextRestoreGState(context);
	
}
#endif

#if (CODE_VERSION > 7)
- (void)drawRect:(CGRect)rect {	
	// Get a graphics context, saving its state
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGContextSaveGState(context);
	
	// Reset the transformation
	CGAffineTransform t0 = CGContextGetCTM(context);
	t0 = CGAffineTransformInvert(t0);
	CGContextConcatCTM(context,t0);
	
	[test draw: context];
	
	CGContextRestoreGState(context);
	
}
#endif


- (void)dealloc {
	[test release];
#if (CODE_VERSION > 7)
	[timer invalidate];
#endif
    [super dealloc];
}


@end
