//
//  AsteroidsView.h
//  Asteroids
//
//  Created by Scott Penberthy on 3/13/10.
//  Copyright 2010 Acme Games. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Sprite.h"

@interface AsteroidsView : UIView {
	Sprite *test;
	NSTimer *timer;
	int frame;
	int direction; 
}

@end
