//
//  Sprite.h
//  Asteroids
//
//  Created by Scott Penberthy on 3/14/10.
//  Copyright 2010 Acme Games. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Defs.h"

@interface Sprite : NSObject {
	CGFloat x;				// x location
	CGFloat y;				// y location
	CGFloat r;				// red tint
	CGFloat g;				// green tint
	CGFloat b;				// blue tint
	CGFloat alpha;			// alpha value, for transparency
	CGFloat speed;			// speed of movement in pixels/frame
	CGFloat angle;			// angle of movement in degrees
	CGFloat rotation;			// rotation of our sprite in degrees, about the center
	CGFloat width;			// width of sprite in pixels
	CGFloat height;                                              // height of sprite in pixels
	CGFloat scale;			// uniform scaling factor for size
	int frame;				// for animation
	
	CGFloat cosTheta;			// pre-computed for speed
	CGFloat sinTheta;	
	CGRect box;			// our bounding box
	
	BOOL render;			// true when we're rendering
	BOOL offScreen;			// true when we're off the screen
	BOOL wrap;			// true if you want the motion to wrap on the screen
}

@property (assign) BOOL wrap, render, offScreen;
@property (assign) CGFloat x, y, r, g, b, alpha;
@property (assign) CGFloat speed, angle, rotation;
@property (assign) CGFloat width, height, scale;
@property (assign) CGRect box;
@property (assign) int frame;

#if (CODE_VERSION > 0)
- (void) updateBox;
- (void) draw: (CGContextRef) context;
#endif

#if (CODE_VERSION > 7) 
- (void) tic: (NSTimeInterval) dt;
#endif

@end

