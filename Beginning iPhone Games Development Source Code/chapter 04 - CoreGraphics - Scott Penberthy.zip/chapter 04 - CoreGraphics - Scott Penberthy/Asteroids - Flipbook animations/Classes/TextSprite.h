//
//  TextSprite.h
//  Asteroids
//
//  Created by Scott Penberthy on 3/15/10.
//  Copyright 2010 Acme Games. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Sprite.h"
#import "Defs.h"

#if (CODE_VERSION > 8)

@interface TextSprite : Sprite {
	NSString *text;
	NSString *font;
	uint fontSize;
	uint textLength;
}

@property (assign) NSString *text;
@property (assign) NSString *font;
@property (assign) uint fontSize;

+ (TextSprite *) withString: (NSString *) label;
- (void) moveUpperLeftTo: (CGPoint) p;
- (void) newText: (NSString *) val;

@end
#endif
