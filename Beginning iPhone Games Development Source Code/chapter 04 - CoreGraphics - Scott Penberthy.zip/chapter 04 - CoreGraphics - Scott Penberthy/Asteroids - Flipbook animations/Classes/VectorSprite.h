//
//  VectorSprite.h
//  Asteroids
//
//  Created by Scott Penberthy on 3/15/10.
//  Copyright 2010 Acme Games. All rights reserved.
//

#import "Defs.h"

#if (CODE_VERSION > 5)

#import <Foundation/Foundation.h>
#include "Sprite.h"

@interface VectorSprite : Sprite {
	CGFloat *points;
	int count;
	CGFloat vectorScale;
}
@property (assign) int count;
@property (assign) CGFloat vectorScale;
@property (assign) CGFloat *points;
+ (VectorSprite *) withPoints: (CGFloat *) rawPoints count: (int) count;
- (void) updateSize;
@end

#endif
