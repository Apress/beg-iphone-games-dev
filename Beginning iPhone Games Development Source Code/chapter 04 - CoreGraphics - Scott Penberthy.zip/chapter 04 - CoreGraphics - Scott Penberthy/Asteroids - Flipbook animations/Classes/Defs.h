/*
 *  Defs.h
 *  Asteroids
 *
 *  Created by Scott Penberthy on 3/17/10.
 *  Copyright 2010 Acme Games. All rights reserved.
 *
 */

//
// Handy #defines to adjust compilation as we work through
// our chapter on Quartz 2D.
//

// Here are the different code versions we use in the Chapter,
// by number
//
// 0 - green rectangle drawn directly, Figure 4-15
// 1 - green rectangle with a Sprite, Figure 4-19
// 2 - green and purple rectangles with a Sprite, Figure 4-20
// 3 - same as 2, but landscape mode without changes, Figure 4-20
// 4 - landscape mode, with updated draw transformation in Sprite class, Figure 4-21 
// 5 - landscape mode, Sprites now center, Figure 4-23
// 6 - introduces the Vector Sprite, Figure 4-27
// 7 - changes the Vector shape to rocks, Figure 4-28
// 8 - Mario the Atlas Sprite, Figure 4-33
// 9 - Hello World Text Sprite, Figure 4-37
//

#define CODE_VERSION 8
