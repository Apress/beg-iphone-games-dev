//
//  Sprite.m
//  Asteroids
//
//  Created by Scott Penberthy on 3/14/10.
//  Copyright 2010 Acme Games. All rights reserved.
//

#import "Sprite.h"

@implementation Sprite
@synthesize x,y,speed,width,height,scale,frame,box,rotation,wrap,render;
@synthesize r,g,b,alpha,offScreen;

- (id) init
{
	self = [super init];
	if (self) {
		wrap = NO;
		x = y = 0.0;
		width = height = 1.0;
		scale = 1.0;
		speed = 0.0;
		angle = 0.0;
		rotation = 0;
		cosTheta = 1.0;
		sinTheta = 0.0;
		r = 1.0;
		g = 1.0;
		b = 1.0;
		alpha = 1.0;
		offScreen = NO;
		box = CGRectMake(0,0,0,0);
		frame = 0;
		render = YES;
	}
	return self;
}


- (void) outlinePath: (CGContextRef) context
{
	// By default, just draw our box outline, assuming our center is at (0,0)
	
	CGFloat w2 = box.size.width*0.5;
	CGFloat h2 = box.size.height*0.5;
	
	CGContextBeginPath(context);
	CGContextSetRGBStrokeColor(context, 0,1,0,alpha);
	CGContextMoveToPoint(context, -w2, h2);
	CGContextAddLineToPoint(context, w2, h2);
	CGContextAddLineToPoint(context, w2, -h2);
	CGContextAddLineToPoint(context, -w2, -h2);
	CGContextAddLineToPoint(context, -w2, h2);
	CGContextClosePath(context);
}

#if (CODE_VERSION < 8)
- (void) updateBox
{
	box.size.width = width;
	box.size.height = height;
	box.origin.x = x;
	box.origin.y = y;
}
#endif

- (void) drawBody: (CGContextRef) context
{	
	CGContextSetRGBFillColor(context, r, g, b, alpha);
	[self outlinePath: context];	
	CGContextDrawPath(context,kCGPathFill);
}

- (void) setRotation: (CGFloat) degrees
{
	rotation = degrees*3.141592/180.0;
}

- (CGFloat) rotation 
{
	return  rotation*180.0/3.141592; 
}

- (void) setAngle: (CGFloat) degrees
{
	angle = degrees*3.141592/180.0;
	cosTheta = cos(angle);
	sinTheta = sin(angle);
}

- (CGFloat) angle
{
	return  angle*180.0/3.141592; 
}


#if (CODE_VERSION > 7)
// 
// Methods added for Atlas Sprite
//
#define kScreenWidth 320
#define kScreenHeight 480
- (void) updateBox
{
	CGFloat w = width*scale;
	CGFloat h = height*scale;
	CGFloat w2 = w*0.5;
	CGFloat h2 = h*0.5;
	CGPoint origin = box.origin;
	CGSize bsize = box.size;
	CGFloat left = -kScreenHeight*0.5;
	CGFloat right = -left;
	CGFloat top = kScreenWidth*0.5;
	CGFloat bottom = -top;
	
	offScreen = NO;
	if (wrap) {
		if ((x+w2) < left) x = right + w2;
		else if ((x-w2) > right) x = left - w2;
		else if ((y+h2) < bottom) y = top + h2;
		else if ((y-h2) > top) y = bottom - h2; 
	}
	else {
		offScreen = 
		((x+w2) < left) ||
		((x-w2) > right) ||
		((y+h2) < bottom) ||
		((y-h2) > top);
	}
	
	origin.x = x-w2*scale;
	origin.y = y-h2*scale;
	bsize.width = w;
	bsize.height = h;
	box.origin = origin;
	box.size = bsize;
}

- (void) tic: (NSTimeInterval) dt
{
	if (!render) return;
	
	CGFloat sdt = speed*dt;
	x += sdt*cosTheta;
	y += sdt*sinTheta;
	if (sdt) [self updateBox];
}
#endif

#if (CODE_VERSION < 4)
- (void) draw: (CGContextRef) context
{
	CGContextSaveGState(context);
	
	// Position the sprite 
	CGAffineTransform t = CGAffineTransformIdentity;
	t = CGAffineTransformTranslate(t,x,y);
	t = CGAffineTransformRotate(t,rotation);
	t = CGAffineTransformScale(t,scale,scale);
	CGContextConcatCTM(context, t);
	
	// Draw our body
	[self drawBody: context];
	
	CGContextRestoreGState(context);
}
#endif


#if (CODE_VERSION == 4) 
- (void) draw: (CGContextRef) context
{
	CGContextSaveGState(context);
	
	// Position the sprite 
	CGAffineTransform t = CGAffineTransformIdentity;
	t = CGAffineTransformTranslate(t,y,480-x);
	t = CGAffineTransformRotate(t,rotation - 3.141592*0.5);
	t = CGAffineTransformScale(t,scale,scale);
	CGContextConcatCTM(context, t);
	
	[self drawBody: context];
	
	CGContextRestoreGState(context);
}
#endif

#if (CODE_VERSION > 4)
- (void) draw: (CGContextRef) context
{
	CGContextSaveGState(context);
	
	// Position the sprite 
	CGAffineTransform t = CGAffineTransformIdentity;
	t = CGAffineTransformTranslate(t,y+160,240-x);
	t = CGAffineTransformRotate(t,rotation - 3.141592*0.5);
	t = CGAffineTransformScale(t,scale,scale);
	CGContextConcatCTM(context, t);
	
	[self drawBody: context];
	CGContextRestoreGState(context);
}
#endif



@end
